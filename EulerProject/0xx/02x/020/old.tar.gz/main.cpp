#include <algorithm>
#include <deque>
#include <fmt/core.h>
#include <iostream>
#include <numeric>

using namespace std;
class bignum {
  public:
    deque<char> nums;
    void mul (int mulnum) {
        deque<char> mulnums;
        while (mulnum) {
            mulnums.push_back (mulnum % 10);
            mulnum /= 10;
        }

        int bit = 0;
        for (auto it = mulnums.begin(); it != mulnums.end(); it++) {
            deque<char> temp (mulsingel (*it));
            for (int i = 0; i < bit; i++)
                temp.push_front (0);
            sum (temp);
            bit++;
        }
        nums = sumnums;
        sumnums = {0};
    }
    void print() {
        for (auto it = nums.rbegin(); it != nums.rend(); it++)
            cout << (int) *it;
        cout << endl;
    }

  private:
    deque<char> sumnums {0};
    deque<char> mulsingel (char bit) {
        deque<char> target (nums);

        int up = 0;
        for (auto it = target.begin(); it != target.end(); it++) {
            *it *= bit;
            *it += up;
            up = 0;
            if (*it >= 10) {
                up = *it / 10;
                *it %= 10;
            }
        }
        if (up)
            target.push_back (up);
        return target;
    }
    void sum (deque<char> addnums) {
        if (addnums.size() > sumnums.size())
            for (int i = 0, loops = (addnums.size() - sumnums.size());
                 i < loops; i++)
                sumnums.push_back (0);
        int up = 0;
        for (int i = 0; i < sumnums.size(); i++) {
            sumnums[i] += addnums[i] + up;
            up = 0;
            if (sumnums[i] > 9) {
                up = 1;
                sumnums[i] -= 10;
            }
        }
        if (up)
            sumnums.push_back (1);
    }
};
int main() {
    bignum ans;
    ans.nums.push_back (1);
    for (int i = 100; i > 0; i--)
        ans.mul (i);
    ans.print();
    fmt::print ("{}", accumulate (ans.nums.begin(), ans.nums.end(), 0));
}
